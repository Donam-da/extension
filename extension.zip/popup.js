// --- HỆ THỐNG BẢN QUYỀN KẾT NỐI VỚI GITHUB GIST CỦA ADMIN ---
const ONLINE_CONFIG_URL = "https://gist.githubusercontent.com/Donam-da/f7c09d917d09209b818bab60c42f2ca3/raw/config.json";
let currentMachineId = "";

function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16).toUpperCase();
    });
}

function showLoginMsg(msg, color = "#ff5252") {
    const el = document.getElementById('login-status');
    el.textContent = msg;
    el.style.color = color;
}

function initLicensing() {
    chrome.storage.local.get(['machineId', 'licenseKey'], async (data) => {
        // 1. Khởi tạo và lấy Mã Máy (HWID)
        if (data.machineId) {
            currentMachineId = data.machineId;
        } else {
            currentMachineId = "EXT-" + generateUUID().substring(0, 8);
            chrome.storage.local.set({ machineId: currentMachineId });
        }
        document.getElementById('hwid-display').textContent = currentMachineId;

        // 2. Kiểm tra Key nếu đã lưu
        if (data.licenseKey) {
            await verifyKeyProcess(data.licenseKey, true);
        } else {
            document.getElementById('login-view').style.display = 'block';
            document.getElementById('main-view').style.display = 'none';
        }
    });
}

async function verifyKeyProcess(key, isAutoLogin = false) {
    if (!isAutoLogin) showLoginMsg("Đang kết nối Server kiểm tra Key...", "#ffb74d");

    try {
        // Tải config.json từ Gist (Thêm tham số thời gian để tránh bị trình duyệt lưu cache)
        const response = await fetch(ONLINE_CONFIG_URL + "?v=" + Date.now());
        const config = await response.json();

        if (config.app_locked) {
            throw new Error("Hệ thống đang bảo trì hoặc bị Admin khóa!");
        }

        if (!config.keys || !config.keys[key]) {
            throw new Error("Khóa cấp phép không tồn tại!");
        }

        const keyData = config.keys[key];

        if (keyData.status === "revoked") {
            throw new Error("Khóa này đã bị Admin tạm dừng hoặc thu hồi!");
        }

        if (keyData.hwid !== "ANY" && keyData.hwid !== currentMachineId) {
            throw new Error("Khóa này dành cho máy khác (Sai Mã Máy)!");
        }

        if (keyData.expiry !== "Vĩnh viễn" && !keyData.expiry.startsWith("DURATION_MINS")) {
            const expDate = new Date(keyData.expiry.replace(" ", "T")); // Đưa về chuẩn ISO để parse
            if (new Date() > expDate) {
                throw new Error("Khóa cấp phép đã hết hạn!");
            }
        }

        // Nếu qua hết các bài test -> KÍCH HOẠT THÀNH CÔNG
        chrome.storage.local.set({ licenseKey: key }, () => {
            document.getElementById('login-view').style.display = 'none';
            document.getElementById('main-view').style.display = 'block';
            loadMainApp(); // Gọi hàm chạy App chính
        });

    } catch (error) {
        if (isAutoLogin) {
            document.getElementById('login-view').style.display = 'block';
            document.getElementById('main-view').style.display = 'none';
        }
        showLoginMsg(error.message, "#ff5252");
        chrome.storage.local.remove(['licenseKey']); // Xóa key lỗi
    }
}

// Lắng nghe sự kiện nút Đăng Nhập
document.getElementById('btn-login').addEventListener('click', () => {
    const key = document.getElementById('key-input').value.trim();
    if (!key) return showLoginMsg("Vui lòng nhập Key!");
    verifyKeyProcess(key, false);
});

// Lắng nghe sự kiện Copy HWID
document.getElementById('btn-copy-hwid').addEventListener('click', (e) => {
    navigator.clipboard.writeText(currentMachineId);
    e.target.textContent = "ĐÃ COPY!";
    setTimeout(() => e.target.textContent = "COPY MÃ MÁY", 2000);
});

// Lắng nghe sự kiện Đăng xuất
document.getElementById('btn-logout').addEventListener('click', () => {
    chrome.storage.local.remove(['licenseKey'], () => {
        document.getElementById('login-view').style.display = 'block';
        document.getElementById('main-view').style.display = 'none';
    });
});

const profiles = {
    samsung: {
        name: "Android 14.0.0 | Chrome v125.0.0.0",
        ua: "Mozilla/5.0 (Linux; Android 14; SM-S908DS) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
        platform: "Linux aarch64",
        hardwareConcurrency: 8,
        deviceMemory: 8,
        screenWidth: 412,
        screenHeight: 915,
        webglVendor: "Qualcomm",
        webglRenderer: "Adreno (TM) 730"
    },
    pixel: {
        name: "Android 13.0.0 | Chrome v120.0.0.0",
        ua: "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        platform: "Linux aarch64",
        hardwareConcurrency: 8,
        deviceMemory: 8,
        screenWidth: 412,
        screenHeight: 915,
        webglVendor: "ARM",
        webglRenderer: "Mali-G710"
    },
    linktot_mobile: {
        name: "Android 14 | Chrome v125 (Chuẩn LinkTot)",
        ua: "Mozilla/5.0 (Linux; Android 14; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
        platform: "Linux aarch64",
        hardwareConcurrency: 8,
        deviceMemory: 8,
        screenWidth: 412,
        screenHeight: 915,
        webglVendor: "Qualcomm",
        webglRenderer: "Adreno (TM) 730"
    }
};

function generateRandomProfile() {
    const brands = ["Xiaomi", "Oppo", "Vivo", "Realme", "OnePlus", "Motorola", "Sony", "Nokia", "Asus", "ZTE", "Infinix"];
    const models = ["Pro", "Ultra", "Plus", "Max", "5G", "Pro+", "Lite", "FE", "Edge", "Power", "Neo", "GT"];
    const brand = brands[Math.floor(Math.random() * brands.length)];
    const model = models[Math.floor(Math.random() * models.length)];
    const androidVer = Math.floor(Math.random() * 6) + 10; // Phiên bản Android từ 10 đến 15

    // Sinh ngẫu nhiên sâu phiên bản Chrome để tạo ra hàng tỷ tổ hợp User-Agent không đụng hàng
    const chromeMajor = Math.floor(Math.random() * (128 - 110 + 1)) + 110;
    const chromeMinor = Math.floor(Math.random() * 5000) + 1000;
    const chromePatch = Math.floor(Math.random() * 200) + 10;

    const w = [360, 384, 393, 412][Math.floor(Math.random() * 4)];
    const h = [800, 854, 873, 915][Math.floor(Math.random() * 4)];

    return {
        name: `Android ${androidVer} | Chrome v${chromeMajor}.${chromeMinor}`,
        ua: `Mozilla/5.0 (Linux; Android ${androidVer}; ${brand} ${model}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeMajor}.0.${chromeMinor}.${chromePatch} Mobile Safari/537.36`,
        platform: "Linux aarch64",
        hardwareConcurrency: [4, 6, 8][Math.floor(Math.random() * 3)],
        deviceMemory: [4, 6, 8, 12][Math.floor(Math.random() * 4)],
        screenWidth: w,
        screenHeight: h,
        webglVendor: "Qualcomm",
        webglRenderer: "Adreno (TM) " + ["610", "618", "620", "640", "650", "730", "740"][Math.floor(Math.random() * 7)]
    };
}

function generateStandardChromeProfile() {
    // Kịch bản 2: Chỉ lấy các máy nguyên bản, chuẩn và cao cấp nhất
    const devices = [
        { name: "SM-S928B", vendor: "Qualcomm", gpu: "Adreno (TM) 750" }, // S24 Ultra
        { name: "SM-S918B", vendor: "Qualcomm", gpu: "Adreno (TM) 740" }, // S23 Ultra
        { name: "SM-S908B", vendor: "Qualcomm", gpu: "Adreno (TM) 730" }, // S22 Ultra
        { name: "Pixel 8 Pro", vendor: "ARM", gpu: "Mali-G715" },
        { name: "Pixel 7", vendor: "ARM", gpu: "Mali-G710" }
    ];
    const dev = devices[Math.floor(Math.random() * devices.length)];
    const androidVer = Math.floor(Math.random() * 2) + 13; // Android 13 hoặc 14
    const chromeVer = Math.floor(Math.random() * 6) + 120; // Chrome 120 - 125

    return {
        name: `Chrome Chuẩn | ${dev.name}`,
        ua: `Mozilla/5.0 (Linux; Android ${androidVer}; ${dev.name}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeVer}.0.0.0 Mobile Safari/537.36`,
        platform: "Linux aarch64",
        hardwareConcurrency: 8,
        deviceMemory: 8,
        screenWidth: [393, 412][Math.floor(Math.random() * 2)],
        screenHeight: [850, 915][Math.floor(Math.random() * 2)],
        webglVendor: dev.vendor,
        webglRenderer: dev.gpu
    };
}

function updateUI(profile) {
    if (!document.getElementById('info-box')) return;
    document.getElementById('info-box').style.display = 'block';
    document.getElementById('current-device').textContent = profile.name + " (" + profile.platform + ")";
    document.getElementById('current-screen').textContent = profile.screenWidth + "x" + profile.screenHeight;
    document.getElementById('current-hw').textContent = profile.deviceMemory + "GB / " + profile.hardwareConcurrency + " Cores";
    document.getElementById('current-webgl').textContent = profile.webglVendor + " - " + profile.webglRenderer;

    let canvasStr = "R:" + (profile.canvasR || 0) + ", G:" + (profile.canvasG || 0) + ", B:" + (profile.canvasB || 0);
    let audioStr = (profile.audioNoise || 0).toFixed(7);
    document.getElementById('current-noise').textContent = "Canvas [" + canvasStr + "] | Audio [" + audioStr + "]";

    document.getElementById('current-ua').textContent = profile.ua;
}

document.getElementById('apply-btn').addEventListener('click', () => {
    const selected = document.getElementById('profile-select').value;
    let profile;
    if (selected === "random") profile = generateRandomProfile();
    else if (selected === "random_chrome_standard" || selected === "random_linktot") profile = generateStandardChromeProfile();
    else profile = profiles[selected];

    // Kịch bản LinkTot: Giảm tối đa tỷ lệ nhiễu (Noise) Canvas/Audio để Chrome thật chuẩn và sạch, vượt qua bài check Captcha gắt gao
    if (selected === "linktot_mobile" || selected === "random_linktot") {
        profile.canvasR = 0;
        profile.canvasG = 0;
        profile.canvasB = 0;
        profile.audioNoise = 0;
        profile.isStrictClean = true;
    } else {
        profile.canvasR = Math.floor(Math.random() * 10) - 5;
        profile.canvasG = Math.floor(Math.random() * 10) - 5;
        profile.canvasB = Math.floor(Math.random() * 10) - 5;
        profile.audioNoise = (Math.random() - 0.5) * 0.0001;
        profile.isStrictClean = false;
    }

    profile.colorDepth = 24;
    const match = profile.ua.match(/(?:Chrome|CriOS)\/(\d+)/);
    profile.chromeMajor = match ? match[1] : "120";
    profile.navigatorVendor = "Google Inc.";

    const btn = document.getElementById('apply-btn');
    const originalText = btn.textContent;
    btn.textContent = "[ ĐANG XÓA SẠCH COOKIE... ]";
    btn.style.background = "#ffb74d";
    btn.style.color = "#000";
    btn.disabled = true;

    // Gọi background xóa sạch Cookie, Cache, Storage trước khi đổi profile
    chrome.runtime.sendMessage({ type: "CLEAR_BROWSING_DATA" }, (response) => {
        chrome.storage.local.set({ spoofProfile: profile }, () => {
            updateUI(profile);
            chrome.runtime.sendMessage({ type: "UPDATE_RULES", profile: profile });

            btn.textContent = "[ THÀNH CÔNG - ĐÃ XÓA SẠCH DATA ]";
            btn.style.background = "#00FF41";
            btn.disabled = false;
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style = "";
            }, 3000);

            // Tự động tải lại tab hiện hành để trang web nhận diện danh tính mới ngay lập tức
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                if (tabs[0]) chrome.tabs.reload(tabs[0].id);
            });
        });
    });
});

document.getElementById('crypto-btn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: "OPEN_CRYPTO_LOGIN" });
});

// Gói logic khởi chạy App chính vào một hàm để gọi sau khi đăng nhập thành công
function loadMainApp() {
    chrome.storage.local.get(['spoofProfile'], (data) => {
        if (data.spoofProfile) {
            updateUI(data.spoofProfile);
        }
    });
}

// Bắt đầu quy trình kiểm tra bản quyền ngay khi mở Extension
initLicensing();
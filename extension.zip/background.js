chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "UPDATE_RULES") {
        const profile = message.profile;
        const ruleId = 1;

        let requestHeaders = [
            { header: "user-agent", operation: "set", value: profile.ua }
        ];

        let fakePlatform = profile.platform.includes("Win") ? "Windows" : profile.platform;
        if (profile.platform.includes("Linux") && profile.ua.includes("Android")) fakePlatform = "Android";
        if (profile.platform.includes("Mac")) fakePlatform = "macOS";

        requestHeaders.push({ header: "sec-ch-ua", operation: "set", value: `"Not/A)Brand";v="8", "Chromium";v="${profile.chromeMajor}", "Google Chrome";v="${profile.chromeMajor}"` });
        requestHeaders.push({ header: "sec-ch-ua-mobile", operation: "set", value: profile.ua.includes("Mobile") ? "?1" : "?0" });
        requestHeaders.push({ header: "sec-ch-ua-platform", operation: "set", value: `"${fakePlatform}"` });

        const newRule = {
            id: ruleId,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: requestHeaders,
                responseHeaders: [
                    { header: "content-security-policy", operation: "remove" }
                ]
            },
            condition: {
                urlFilter: "*",
                resourceTypes: ["main_frame", "sub_frame", "xmlhttprequest", "ping", "script", "stylesheet", "image"]
            }
        };
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [ruleId],
            addRules: [newRule]
        });
    } else if (message.type === "CLEAR_BROWSING_DATA") {
        // Xóa sạch toàn bộ Cookie, Cache, LocalStorage để web quên danh tính cũ
        chrome.browsingData.remove({
            "since": 0
        }, {
            "appcache": false,
            "cache": false,
            "cacheStorage": false,
            "cookies": true,
            "fileSystems": true,
            "indexedDB": true,
            "localStorage": true,
            "pluginData": false,
            "serviceWorkers": true,
            "webSQL": true
        }, () => {
            sendResponse({ success: true });
        });
        return true; // Giữ kênh giao tiếp mở để gửi callback
    } else if (message.type === "OPEN_CRYPTO_LOGIN") {
        chrome.tabs.create({ url: "https://cryptolinkforearn.com/login" }, (tab) => {
            const listener = function (tabId, changeInfo, updatedTab) {
                if (tabId === tab.id && changeInfo.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(listener);
                    chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            setTimeout(() => {
                                const emailInput = document.querySelector('input[name="email"], input[type="email"]');
                                const passInput = document.querySelector('input[name="password"], input[type="password"]');
                                if (emailInput && passInput) {
                                    emailInput.value = 'namhackmap18@gmail.com';
                                    passInput.value = 'nam523181';
                                    emailInput.dispatchEvent(new Event('input', { bubbles: true }));
                                    passInput.dispatchEvent(new Event('input', { bubbles: true }));

                                    const btn = document.querySelector('button[type="submit"]');
                                    if (btn) btn.click();
                                }
                            }, 800);
                        }
                    }).catch(err => console.log(err));
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
        });
    }
});